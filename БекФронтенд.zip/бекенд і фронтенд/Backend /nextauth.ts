import NextAuth, { type NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { db }              from '@/db';
import { users }           from '@/db/schema';
import { eq }              from 'drizzle-orm';
import bcrypt              from 'bcryptjs';

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'Email & Password',
      credentials: {
        email:    { label: 'Email',    type: 'email'    },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null;

        const [user] = await db
          .select()
          .from(users)
          .where(eq(users.email, credentials.email.toLowerCase()))
          .limit(1);

        if (!user || !user.passwordHash) return null;

        const valid = await bcrypt.compare(credentials.password, user.passwordHash);
        if (!valid) return null;

        return {
          id:       String(user.id),
          email:    user.email,
          name:     user.name ?? undefined,
          theme:    user.theme,
          language: user.language,
        };
      },
    }),
  ],

  session: {
    strategy: 'jwt',
    maxAge:   30 * 24 * 60 * 60, // 30 days
  },

  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id       = user.id;
        token.theme    = (user as Record<string, unknown>).theme;
        token.language = (user as Record<string, unknown>).language;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as Record<string, unknown>).id       = token.id;
        (session.user as Record<string, unknown>).theme    = token.theme;
        (session.user as Record<string, unknown>).language = token.language;
      }
      return session;
    },
  },

  pages: {
    signIn: '/auth/login',
    error:  '/auth/error',
  },

  secret: process.env.NEXTAUTH_SECRET,
};

export default NextAuth(authOptions);
