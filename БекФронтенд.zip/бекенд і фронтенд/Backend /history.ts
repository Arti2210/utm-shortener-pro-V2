import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession }  from 'next-auth/next';
import { authOptions }       from '@/pages/api/auth/[...nextauth]';
import { db }                from '@/db';
import { generatedLinks }    from '@/db/schema';
import { eq, and, gt, desc, asc, like } from 'drizzle-orm';
import { ok, err, methodNotAllowed }     from '@/lib/response';

const PAGE_SIZE = 20;

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);

  const session = await getServerSession(req, res, authOptions);
  if (!session?.user) return err(res, 'Authentication required', 401);

  const userId  = parseInt((session.user as Record<string, unknown>).id as string, 10);
  const page    = Math.max(1, parseInt(String(req.query.page ?? '1'), 10));
  const search  = String(req.query.search ?? '').trim();
  const sortDir = req.query.sort === 'asc' ? asc : desc;

  const now     = new Date();
  const offset  = (page - 1) * PAGE_SIZE;

  const conditions = [
    eq(generatedLinks.userId, userId),
    gt(generatedLinks.expiresAt, now),
    ...(search ? [like(generatedLinks.campaignName, `%${search}%`)] : []),
  ];

  const rows = await db
    .select()
    .from(generatedLinks)
    .where(and(...conditions))
    .orderBy(sortDir(generatedLinks.createdAt))
    .limit(PAGE_SIZE)
    .offset(offset);

  return ok(res, {
    items:    rows,
    page,
    pageSize: PAGE_SIZE,
    hasMore:  rows.length === PAGE_SIZE,
  });
}
