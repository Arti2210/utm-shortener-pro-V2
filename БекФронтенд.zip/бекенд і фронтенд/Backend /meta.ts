import type { NextApiRequest, NextApiResponse } from 'next';
import { db }       from '@/db';
import { platforms, mediums } from '@/db/schema';
import { eq }       from 'drizzle-orm';
import { ok, err, methodNotAllowed } from '@/lib/response';

/**
 * GET /api/meta — returns active platforms and mediums.
 * Public endpoint (no auth required). Suitable for caching.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);

  const [activePlatforms, activeMediums] = await Promise.all([
    db.select().from(platforms).where(eq(platforms.isActive, 1)),
    db.select().from(mediums).where(eq(mediums.isActive, 1)),
  ]);

  // Cache for 5 minutes on the CDN edge
  res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=600');

  return ok(res, {
    platforms: activePlatforms,
    mediums:   activeMediums,
  });
}
