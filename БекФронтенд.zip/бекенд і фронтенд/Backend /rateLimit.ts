/**
 * Simple in-memory rate limiter.
 * For production, swap the store with Redis (ioredis + sliding window).
 */

interface RateRecord {
  count:     number;
  resetTime: number;
}

const store = new Map<string, RateRecord>();

// Cleanup expired records every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of store.entries()) {
    if (now > record.resetTime) store.delete(key);
  }
}, 5 * 60 * 1000);

export interface RateLimitOptions {
  /** Max requests in the window */
  limit:    number;
  /** Window size in seconds */
  windowMs: number;
}

export interface RateLimitResult {
  allowed:   boolean;
  remaining: number;
  resetTime: number;
}

export function checkRateLimit(
  identifier: string,
  { limit, windowMs }: RateLimitOptions,
): RateLimitResult {
  const now      = Date.now();
  const key      = identifier;
  const record   = store.get(key);
  const resetAt  = record && now < record.resetTime ? record.resetTime : now + windowMs * 1000;

  if (!record || now > record.resetTime) {
    store.set(key, { count: 1, resetTime: resetAt });
    return { allowed: true, remaining: limit - 1, resetTime: resetAt };
  }

  if (record.count >= limit) {
    return { allowed: false, remaining: 0, resetTime: record.resetTime };
  }

  record.count += 1;
  return { allowed: true, remaining: limit - record.count, resetTime: record.resetTime };
}

/**
 * Extracts the client IP from a Next.js request.
 */
export function getClientIp(req: { headers: Record<string, string | string[] | undefined>; socket?: { remoteAddress?: string } }): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    return (Array.isArray(forwarded) ? forwarded[0] : forwarded).split(',')[0].trim();
  }
  return req.socket?.remoteAddress ?? 'unknown';
}
