// ─── TinyURL API Integration ──────────────────────────────────────────────────

const TINYURL_API_BASE = 'https://api.tinyurl.com';

export interface ShortenResult {
  originalUrl: string;
  shortUrl:    string | null;
  status:      'success' | 'error';
  error?:      string;
}

interface TinyUrlSuccessResponse {
  code: number;
  data: {
    domain:    string;
    alias:     string;
    deleted:   boolean;
    archived:  boolean;
    analytics: unknown[];
    tags:      string[];
    url:        string;
    tiny_url:   string;
  };
}

/**
 * Shortens a single URL via TinyURL API v2.
 */
export async function shortenUrl(
  url:    string,
  apiKey: string,
): Promise<ShortenResult> {
  try {
    const res = await fetch(`${TINYURL_API_BASE}/create`, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ url, domain: 'tinyurl.com' }),
    });

    if (res.status === 401) {
      return { originalUrl: url, shortUrl: null, status: 'error', error: 'Invalid or expired TinyURL API key' };
    }
    if (res.status === 429) {
      return { originalUrl: url, shortUrl: null, status: 'error', error: 'TinyURL rate limit exceeded. Try again later.' };
    }
    if (res.status === 422) {
      const body = await res.json().catch(() => ({}));
      return {
        originalUrl: url,
        shortUrl:    null,
        status:      'error',
        error:       body?.errors?.[0] ?? 'Invalid URL — TinyURL could not process it.',
      };
    }
    if (!res.ok) {
      return { originalUrl: url, shortUrl: null, status: 'error', error: `TinyURL API error (HTTP ${res.status})` };
    }

    const data: TinyUrlSuccessResponse = await res.json();
    return {
      originalUrl: url,
      shortUrl:    data.data.tiny_url,
      status:      'success',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Network error';
    return { originalUrl: url, shortUrl: null, status: 'error', error: message };
  }
}

/**
 * Batch-shortens URLs with a small delay between requests
 * to avoid hitting rate limits.
 */
export async function shortenBatch(
  urls:    string[],
  apiKey:  string,
  delayMs: number = 100,
): Promise<ShortenResult[]> {
  const results: ShortenResult[] = [];

  for (const url of urls) {
    const result = await shortenUrl(url, apiKey);
    results.push(result);

    // If we hit a rate limit, abort the rest
    if (result.error?.includes('rate limit')) break;

    if (delayMs > 0 && urls.indexOf(url) < urls.length - 1) {
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }

  return results;
}

/**
 * Validates a TinyURL API key by making a lightweight test request.
 */
export async function validateApiKey(apiKey: string): Promise<boolean> {
  try {
    const res = await fetch(`${TINYURL_API_BASE}/create`, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ url: 'https://example.com', domain: 'tinyurl.com' }),
    });
    return res.status !== 401;
  } catch {
    return false;
  }
}
