import type { NextApiResponse } from 'next';

export interface ApiSuccess<T = unknown> {
  success: true;
  data:    T;
}

export interface ApiError {
  success: false;
  error:   string;
  details?: unknown;
}

export type ApiResponse<T = unknown> = ApiSuccess<T> | ApiError;

export function ok<T>(res: NextApiResponse, data: T, status = 200): void {
  res.status(status).json({ success: true, data } satisfies ApiSuccess<T>);
}

export function err(
  res:     NextApiResponse,
  message: string,
  status:  number  = 400,
  details?: unknown,
): void {
  res.status(status).json({ success: false, error: message, details } satisfies ApiError);
}

export function methodNotAllowed(res: NextApiResponse, allowed: string[]): void {
  res.setHeader('Allow', allowed.join(', '));
  err(res, `Method not allowed. Allowed: ${allowed.join(', ')}`, 405);
}
