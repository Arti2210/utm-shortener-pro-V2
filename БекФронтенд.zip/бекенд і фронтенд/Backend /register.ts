import type { NextApiRequest, NextApiResponse } from 'next';
import bcrypt from 'bcryptjs';
import { db }    from '@/db';
import { users } from '@/db/schema';
import { eq }    from 'drizzle-orm';
import { ok, err, methodNotAllowed } from '@/lib/response';
import { checkRateLimit, getClientIp } from '@/lib/rateLimit';

interface RegisterBody {
  email:    string;
  password: string;
  name?:    string;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);

  // Rate limit: 5 registrations per IP per hour
  const ip     = getClientIp(req);
  const limit  = checkRateLimit(`register:${ip}`, { limit: 5, windowMs: 3600 });
  if (!limit.allowed) {
    return err(res, 'Too many registration attempts. Try again later.', 429);
  }

  const { email, password, name } = req.body as RegisterBody;

  if (!email || !password) {
    return err(res, 'Email and password are required');
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return err(res, 'Invalid email format');
  }

  if (password.length < 8) {
    return err(res, 'Password must be at least 8 characters');
  }

  const [existing] = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, email.toLowerCase()))
    .limit(1);

  if (existing) {
    return err(res, 'Email already registered', 409);
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const [result] = await db.insert(users).values({
    email:        email.toLowerCase().trim(),
    name:         name?.trim() ?? null,
    passwordHash,
    theme:        'light',
    language:     'uk',
  });

  return ok(res, { id: (result as { insertId: number }).insertId, email: email.toLowerCase() }, 201);
}
