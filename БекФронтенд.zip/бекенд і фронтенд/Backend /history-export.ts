import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions }      from '@/pages/api/auth/[...nextauth]';
import { db }               from '@/db';
import { generatedLinks }   from '@/db/schema';
import { eq, and, gt, desc } from 'drizzle-orm';
import { methodNotAllowed, err } from '@/lib/response';

function escapeCsv(value: string | null | undefined): string {
  if (value == null) return '';
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

const CSV_HEADERS = [
  'ID', 'Campaign', 'Source', 'Medium',
  'Base URL', 'Full UTM URL', 'Short URL', 'Status', 'Created At',
];

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') return methodNotAllowed(res, ['GET']);

  const session = await getServerSession(req, res, authOptions);
  if (!session?.user) return err(res, 'Authentication required', 401);

  const userId = parseInt((session.user as Record<string, unknown>).id as string, 10);
  const now    = new Date();

  const rows = await db
    .select()
    .from(generatedLinks)
    .where(and(eq(generatedLinks.userId, userId), gt(generatedLinks.expiresAt, now)))
    .orderBy(desc(generatedLinks.createdAt))
    .limit(5000); // Safety cap

  const lines: string[] = [CSV_HEADERS.join(',')];
  for (const row of rows) {
    lines.push([
      row.id,
      escapeCsv(row.campaignName),
      escapeCsv(row.source),
      escapeCsv(row.medium),
      escapeCsv(row.baseUrl),
      escapeCsv(row.fullUtmUrl),
      escapeCsv(row.shortUrl),
      row.status,
      row.createdAt.toISOString(),
    ].join(','));
  }

  const filename = `utm-history-${new Date().toISOString().slice(0, 10)}.csv`;
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
  res.status(200).send('\uFEFF' + lines.join('\n')); // BOM for Excel
}
