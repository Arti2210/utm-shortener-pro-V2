/**
 * Seed script — run once after db:push
 * npx tsx src/db/seed.ts
 */
import { db } from './index';
import { platforms, mediums } from './schema';

const PLATFORMS = [
  { name: 'Telegram',  code: 'tg' },
  { name: 'Facebook',  code: 'fb' },
  { name: 'LinkedIn',  code: 'li' },
  { name: 'Instagram', code: 'ig' },
  { name: 'Threads',   code: 'th' },
  { name: 'Twitter/X', code: 'tw' },
  { name: 'YouTube',   code: 'yt' },
];

const MEDIUMS = [
  { name: 'Post',    code: 'post' },
  { name: 'Story',   code: 'story' },
  { name: 'Reels',   code: 'reels' },
  { name: 'Bio',     code: 'bio' },
  { name: 'Comment', code: 'comment' },
];

async function seed() {
  console.log('🌱 Seeding database...');

  for (const p of PLATFORMS) {
    await db.insert(platforms).ignore().values({ ...p, isActive: 1 });
    console.log(`  Platform: ${p.name}`);
  }

  for (const m of MEDIUMS) {
    await db.insert(mediums).ignore().values({ ...m, isActive: 1 });
    console.log(`  Medium: ${m.name}`);
  }

  console.log('✅ Seed complete.');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
