import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions }      from '@/pages/api/auth/[...nextauth]';
import { db }               from '@/db';
import { users }            from '@/db/schema';
import { eq }               from 'drizzle-orm';
import { validateSettingsInput } from '@/lib/validation';
import { ok, err, methodNotAllowed } from '@/lib/response';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (!['GET', 'POST', 'PATCH'].includes(req.method!)) {
    return methodNotAllowed(res, ['GET', 'POST', 'PATCH']);
  }

  const session = await getServerSession(req, res, authOptions);
  if (!session?.user) {
    return err(res, 'Authentication required', 401);
  }

  const userId = parseInt((session.user as Record<string, unknown>).id as string, 10);

  // ─── GET ──────────────────────────────────────────────────────────────────
  if (req.method === 'GET') {
    const [user] = await db
      .select({
        id:            users.id,
        email:         users.email,
        name:          users.name,
        theme:         users.theme,
        language:      users.language,
        tinyUrlApiKey: users.tinyUrlApiKey,
      })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);

    if (!user) return err(res, 'User not found', 404);
    return ok(res, user);
  }

  // ─── POST / PATCH ─────────────────────────────────────────────────────────
  const validation = validateSettingsInput(req.body);
  if (!validation.valid) {
    return err(res, 'Validation failed', 400, validation.errors);
  }

  const { data } = validation;
  if (Object.keys(data).length === 0) {
    return err(res, 'No fields to update');
  }

  await db
    .update(users)
    .set(data)
    .where(eq(users.id, userId));

  const [updated] = await db
    .select({
      id:            users.id,
      email:         users.email,
      name:          users.name,
      theme:         users.theme,
      language:      users.language,
      tinyUrlApiKey: users.tinyUrlApiKey,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  return ok(res, updated);
}
