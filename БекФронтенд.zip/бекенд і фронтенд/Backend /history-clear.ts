import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession } from 'next-auth/next';
import { authOptions }      from '@/pages/api/auth/[...nextauth]';
import { db }               from '@/db';
import { generatedLinks }   from '@/db/schema';
import { eq }               from 'drizzle-orm';
import { ok, err, methodNotAllowed } from '@/lib/response';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);

  const session = await getServerSession(req, res, authOptions);
  if (!session?.user) return err(res, 'Authentication required', 401);

  const userId = parseInt((session.user as Record<string, unknown>).id as string, 10);

  await db
    .delete(generatedLinks)
    .where(eq(generatedLinks.userId, userId));

  return ok(res, { cleared: true });
}
