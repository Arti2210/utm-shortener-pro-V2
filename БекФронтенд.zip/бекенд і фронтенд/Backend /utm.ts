// ─── UTM Utilities ────────────────────────────────────────────────────────────

export interface UtmCombination {
  source: string;
  medium: string;
}

export interface UtmResult {
  source:     string;
  medium:     string;
  fullUtmUrl: string;
}

export interface ValidationResult {
  valid:   boolean;
  message: string;
}

// Characters allowed in UTM parameter values (RFC 3986 unreserved + common extras)
const SAFE_UTM_PATTERN = /^[a-zA-Z0-9_\-\.~]+$/;

/**
 * Validates a URL string using the native URL constructor.
 */
export function validateUrl(url: string): ValidationResult {
  if (!url || url.trim().length === 0) {
    return { valid: false, message: 'URL is required' };
  }

  try {
    const parsed = new URL(url.trim());
    if (!['http:', 'https:'].includes(parsed.protocol)) {
      return { valid: false, message: 'URL must use http or https protocol' };
    }
    return { valid: true, message: '' };
  } catch {
    return { valid: false, message: 'Invalid URL format' };
  }
}

/**
 * Validates a UTM campaign name.
 * Allows letters, digits, underscores, hyphens. Max 100 chars.
 */
export function validateCampaignName(name: string): ValidationResult {
  if (!name || name.trim().length === 0) {
    return { valid: false, message: 'Campaign name is required' };
  }
  if (name.length > 100) {
    return { valid: false, message: 'Campaign name must be 100 characters or less' };
  }
  if (!SAFE_UTM_PATTERN.test(name)) {
    return {
      valid:   false,
      message: 'Campaign name may only contain letters, digits, underscores, hyphens and dots',
    };
  }
  return { valid: true, message: '' };
}

/**
 * Builds a single UTM URL.
 * Existing UTM params on the base URL are intentionally stripped and replaced.
 */
export function buildUtmUrl(
  baseUrl:      string,
  campaignName: string,
  source:       string,
  medium:       string,
): string {
  const url = new URL(baseUrl.trim());

  // Remove any existing UTM params
  ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach((p) =>
    url.searchParams.delete(p),
  );

  url.searchParams.set('utm_campaign', campaignName.trim().toLowerCase());
  url.searchParams.set('utm_source',   source.trim().toLowerCase());
  url.searchParams.set('utm_medium',   medium.trim().toLowerCase());

  return url.toString();
}

/**
 * Generates UTM URLs for all provided source/medium combinations.
 */
export function generateUtmBatch(
  baseUrl:      string,
  campaignName: string,
  combinations: UtmCombination[],
): UtmResult[] {
  return combinations.map(({ source, medium }) => ({
    source,
    medium,
    fullUtmUrl: buildUtmUrl(baseUrl, campaignName, source, medium),
  }));
}
