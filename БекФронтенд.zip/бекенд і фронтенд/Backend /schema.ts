import {
  mysqlTable,
  varchar,
  int,
  text,
  timestamp,
  tinyint,
  mysqlEnum,
  index,
} from 'drizzle-orm/mysql-core';
import { sql } from 'drizzle-orm';

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = mysqlTable('users', {
  id:             int('id').primaryKey().autoincrement(),
  email:          varchar('email', { length: 255 }).notNull().unique(),
  name:           varchar('name', { length: 255 }),
  passwordHash:   varchar('password_hash', { length: 255 }),
  theme:          mysqlEnum('theme', ['light', 'dark']).default('light').notNull(),
  language:       mysqlEnum('language', ['uk', 'en']).default('uk').notNull(),
  tinyUrlApiKey:  varchar('tinyurl_api_key', { length: 255 }),
  createdAt:      timestamp('created_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
  updatedAt:      timestamp('updated_at').default(sql`CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP`).notNull(),
});

// ─── Platforms ────────────────────────────────────────────────────────────────
export const platforms = mysqlTable('platforms', {
  id:       int('id').primaryKey().autoincrement(),
  name:     varchar('name', { length: 100 }).notNull(),
  code:     varchar('code', { length: 50 }).notNull().unique(),
  isActive: tinyint('is_active').default(1).notNull(),
});

// ─── Mediums ──────────────────────────────────────────────────────────────────
export const mediums = mysqlTable('mediums', {
  id:       int('id').primaryKey().autoincrement(),
  name:     varchar('name', { length: 100 }).notNull(),
  code:     varchar('code', { length: 50 }).notNull().unique(),
  isActive: tinyint('is_active').default(1).notNull(),
});

// ─── Generated Links ──────────────────────────────────────────────────────────
export const generatedLinks = mysqlTable(
  'generated_links',
  {
    id:           int('id').primaryKey().autoincrement(),
    userId:       int('user_id').references(() => users.id, { onDelete: 'cascade' }),
    baseUrl:      text('base_url').notNull(),
    campaignName: varchar('campaign_name', { length: 255 }).notNull(),
    source:       varchar('source', { length: 100 }).notNull(),
    medium:       varchar('medium', { length: 100 }).notNull(),
    fullUtmUrl:   text('full_utm_url').notNull(),
    shortUrl:     text('short_url'),
    status:       mysqlEnum('status', ['success', 'error', 'pending']).default('pending').notNull(),
    errorMessage: text('error_message'),
    expiresAt:    timestamp('expires_at').notNull(),
    createdAt:    timestamp('created_at').default(sql`CURRENT_TIMESTAMP`).notNull(),
  },
  (table) => ({
    userIdx:    index('idx_user_id').on(table.userId),
    expiresIdx: index('idx_expires_at').on(table.expiresAt),
    createdIdx: index('idx_created_at').on(table.createdAt),
  }),
);

// ─── Sessions (NextAuth) ──────────────────────────────────────────────────────
export const accounts = mysqlTable('accounts', {
  id:                int('id').primaryKey().autoincrement(),
  userId:            int('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  type:              varchar('type', { length: 255 }).notNull(),
  provider:          varchar('provider', { length: 255 }).notNull(),
  providerAccountId: varchar('provider_account_id', { length: 255 }).notNull(),
  refreshToken:      text('refresh_token'),
  accessToken:       text('access_token'),
  expiresAt:         int('expires_at'),
  tokenType:         varchar('token_type', { length: 255 }),
  scope:             varchar('scope', { length: 255 }),
  idToken:           text('id_token'),
  sessionState:      varchar('session_state', { length: 255 }),
});

export const sessions = mysqlTable('sessions', {
  id:           int('id').primaryKey().autoincrement(),
  sessionToken: varchar('session_token', { length: 255 }).notNull().unique(),
  userId:       int('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  expires:      timestamp('expires').notNull(),
});

export const verificationTokens = mysqlTable('verification_tokens', {
  identifier: varchar('identifier', { length: 255 }).notNull(),
  token:      varchar('token', { length: 255 }).notNull().unique(),
  expires:    timestamp('expires').notNull(),
});

// ─── Type exports ─────────────────────────────────────────────────────────────
export type User             = typeof users.$inferSelect;
export type NewUser          = typeof users.$inferInsert;
export type Platform         = typeof platforms.$inferSelect;
export type Medium           = typeof mediums.$inferSelect;
export type GeneratedLink    = typeof generatedLinks.$inferSelect;
export type NewGeneratedLink = typeof generatedLinks.$inferInsert;
