import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import * as schema from './schema';

// Singleton pool (works in Next.js API routes with hot-reload)
declare global {
  // eslint-disable-next-line no-var
  var _mysqlPool: mysql.Pool | undefined;
}

function createPool(): mysql.Pool {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL environment variable is not set');
  }

  return mysql.createPool({
    uri:               process.env.DATABASE_URL,
    waitForConnections: true,
    connectionLimit:   10,
    queueLimit:        0,
    enableKeepAlive:   true,
    keepAliveInitialDelay: 0,
  });
}

const pool = globalThis._mysqlPool ?? createPool();

if (process.env.NODE_ENV !== 'production') {
  globalThis._mysqlPool = pool;
}

export const db = drizzle(pool, { schema, mode: 'default' });

export { pool };
export type DB = typeof db;
