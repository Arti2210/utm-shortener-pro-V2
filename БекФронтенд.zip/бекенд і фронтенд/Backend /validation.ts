// ─── Input Validation ─────────────────────────────────────────────────────────

export interface GenerateLinksInput {
  baseUrl:      string;
  campaignName: string;
  combinations: Array<{ source: string; medium: string }>;
  apiKey:       string;
}

export interface ValidationError {
  field:   string;
  message: string;
}

const URL_PATTERN  = /^https?:\/\/.+/;
const SAFE_PATTERN = /^[a-zA-Z0-9_\-\.~]+$/;

function isString(v: unknown): v is string {
  return typeof v === 'string';
}

/**
 * Validates the payload for POST /api/links/generate
 */
export function validateGenerateInput(
  body: unknown,
): { valid: true; data: GenerateLinksInput } | { valid: false; errors: ValidationError[] } {
  const errors: ValidationError[] = [];

  if (!body || typeof body !== 'object') {
    return { valid: false, errors: [{ field: 'body', message: 'Request body is required' }] };
  }

  const b = body as Record<string, unknown>;

  // baseUrl
  if (!isString(b.baseUrl) || !b.baseUrl.trim()) {
    errors.push({ field: 'baseUrl', message: 'baseUrl is required' });
  } else if (!URL_PATTERN.test(b.baseUrl.trim())) {
    errors.push({ field: 'baseUrl', message: 'baseUrl must be a valid http/https URL' });
  } else {
    try { new URL(b.baseUrl.trim()); }
    catch { errors.push({ field: 'baseUrl', message: 'baseUrl is not a valid URL' }); }
  }

  // campaignName
  if (!isString(b.campaignName) || !b.campaignName.trim()) {
    errors.push({ field: 'campaignName', message: 'campaignName is required' });
  } else if (b.campaignName.length > 100) {
    errors.push({ field: 'campaignName', message: 'campaignName must be ≤100 characters' });
  } else if (!SAFE_PATTERN.test(b.campaignName)) {
    errors.push({ field: 'campaignName', message: 'campaignName contains invalid characters' });
  }

  // combinations
  if (!Array.isArray(b.combinations) || b.combinations.length === 0) {
    errors.push({ field: 'combinations', message: 'At least one combination is required' });
  } else if (b.combinations.length > 50) {
    errors.push({ field: 'combinations', message: 'Maximum 50 combinations per request' });
  } else {
    b.combinations.forEach((c, i) => {
      if (!c || typeof c !== 'object') {
        errors.push({ field: `combinations[${i}]`, message: 'Must be an object' });
        return;
      }
      const combo = c as Record<string, unknown>;
      if (!isString(combo.source) || !combo.source.trim()) {
        errors.push({ field: `combinations[${i}].source`, message: 'source is required' });
      }
      if (!isString(combo.medium) || !combo.medium.trim()) {
        errors.push({ field: `combinations[${i}].medium`, message: 'medium is required' });
      }
    });
  }

  // apiKey
  if (!isString(b.apiKey) || !b.apiKey.trim()) {
    errors.push({ field: 'apiKey', message: 'TinyURL API key is required' });
  }

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  return {
    valid: true,
    data: {
      baseUrl:      (b.baseUrl as string).trim(),
      campaignName: (b.campaignName as string).trim(),
      combinations: (b.combinations as Array<{ source: string; medium: string }>).map((c) => ({
        source: c.source.trim().toLowerCase(),
        medium: c.medium.trim().toLowerCase(),
      })),
      apiKey: (b.apiKey as string).trim(),
    },
  };
}

export interface SettingsUpdateInput {
  theme?:         'light' | 'dark';
  language?:      'uk' | 'en';
  tinyUrlApiKey?: string;
}

export function validateSettingsInput(
  body: unknown,
): { valid: true; data: SettingsUpdateInput } | { valid: false; errors: ValidationError[] } {
  const errors: ValidationError[] = [];

  if (!body || typeof body !== 'object') {
    return { valid: false, errors: [{ field: 'body', message: 'Request body is required' }] };
  }

  const b = body as Record<string, unknown>;
  const data: SettingsUpdateInput = {};

  if (b.theme !== undefined) {
    if (!['light', 'dark'].includes(b.theme as string)) {
      errors.push({ field: 'theme', message: "theme must be 'light' or 'dark'" });
    } else {
      data.theme = b.theme as 'light' | 'dark';
    }
  }

  if (b.language !== undefined) {
    if (!['uk', 'en'].includes(b.language as string)) {
      errors.push({ field: 'language', message: "language must be 'uk' or 'en'" });
    } else {
      data.language = b.language as 'uk' | 'en';
    }
  }

  if (b.tinyUrlApiKey !== undefined) {
    if (!isString(b.tinyUrlApiKey)) {
      errors.push({ field: 'tinyUrlApiKey', message: 'tinyUrlApiKey must be a string' });
    } else {
      data.tinyUrlApiKey = b.tinyUrlApiKey.trim();
    }
  }

  if (errors.length > 0) return { valid: false, errors };
  return { valid: true, data };
}
