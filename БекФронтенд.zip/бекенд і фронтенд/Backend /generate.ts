import type { NextApiRequest, NextApiResponse } from 'next';
import { getServerSession }  from 'next-auth/next';
import { authOptions }       from '@/pages/api/auth/[...nextauth]';
import { db }                from '@/db';
import { generatedLinks }    from '@/db/schema';
import { generateUtmBatch }  from '@/utils/utm';
import { shortenBatch }      from '@/utils/tinyurl';
import { validateGenerateInput } from '@/lib/validation';
import { ok, err, methodNotAllowed } from '@/lib/response';
import { checkRateLimit, getClientIp } from '@/lib/rateLimit';
import { addDays } from 'date-fns';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);

  // Rate limit: 30 generations per IP per minute
  const ip    = getClientIp(req);
  const limit = checkRateLimit(`generate:${ip}`, { limit: 30, windowMs: 60 });
  if (!limit.allowed) {
    res.setHeader('X-RateLimit-Reset', String(limit.resetTime));
    return err(res, 'Rate limit exceeded. Please wait before generating more links.', 429);
  }

  // Validate input
  const validation = validateGenerateInput(req.body);
  if (!validation.valid) {
    return err(res, 'Validation failed', 400, validation.errors);
  }

  const { baseUrl, campaignName, combinations, apiKey } = validation.data;

  // Build UTM URLs
  const utmResults = generateUtmBatch(baseUrl, campaignName, combinations);

  // Shorten via TinyURL
  const shortResults = await shortenBatch(
    utmResults.map((r) => r.fullUtmUrl),
    apiKey,
    150, // 150 ms delay between requests
  );

  // Merge results
  const merged = utmResults.map((utm, i) => {
    const short = shortResults[i];
    return {
      source:      utm.source,
      medium:      utm.medium,
      fullUtmUrl:  utm.fullUtmUrl,
      shortUrl:    short?.shortUrl ?? null,
      status:      short?.status ?? 'error',
      error:       short?.error,
    };
  });

  // Persist to DB (optional: only if user is authenticated)
  const session = await getServerSession(req, res, authOptions);
  if (session?.user) {
    const userId   = parseInt((session.user as Record<string, unknown>).id as string, 10);
    const expiresAt = addDays(new Date(), 7);

    const rows = merged.map((m) => ({
      userId,
      baseUrl,
      campaignName,
      source:      m.source,
      medium:      m.medium,
      fullUtmUrl:  m.fullUtmUrl,
      shortUrl:    m.shortUrl ?? undefined,
      status:      m.status as 'success' | 'error' | 'pending',
      errorMessage: m.error ?? undefined,
      expiresAt,
    }));

    // Fire-and-forget — don't block the response
    db.insert(generatedLinks)
      .values(rows)
      .catch((e) => console.error('[DB] Failed to persist links:', e));
  }

  return ok(res, merged);
}
