import type { NextApiRequest, NextApiResponse } from 'next';
import { validateApiKey }   from '@/utils/tinyurl';
import { ok, err, methodNotAllowed } from '@/lib/response';
import { checkRateLimit, getClientIp } from '@/lib/rateLimit';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return methodNotAllowed(res, ['POST']);

  const ip    = getClientIp(req);
  const limit = checkRateLimit(`validate-key:${ip}`, { limit: 10, windowMs: 60 });
  if (!limit.allowed) {
    return err(res, 'Too many validation requests.', 429);
  }

  const { apiKey } = req.body as { apiKey?: string };
  if (!apiKey || typeof apiKey !== 'string' || !apiKey.trim()) {
    return err(res, 'apiKey is required');
  }

  const valid = await validateApiKey(apiKey.trim());
  return ok(res, { valid });
}
