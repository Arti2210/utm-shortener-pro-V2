
import { useAppStore } from '@/store/appStore';

export default function Header({ onOpenSettings }: { onOpenSettings: () => void }) {
  const { language, theme, setLanguage, setTheme } = useAppStore();

  return (
    <header className="h-[70px] border-b border-gold-400/20 px-6 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <img src="/logo.png" alt="Logo" className="w-10 h-10" />
        <h1 className="font-bold text-xl">UTM Shortener Pro</h1>
      </div>

      <div className="flex items-center gap-3">
        <button onClick={() => setLanguage(language === 'uk' ? 'en' : 'uk')}>
          {language.toUpperCase()}
        </button>

        <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
          {theme === 'dark' ? '🌙' : '☀️'}
        </button>

        <button onClick={onOpenSettings}>⚙️</button>
      </div>
    </header>
  );
}
