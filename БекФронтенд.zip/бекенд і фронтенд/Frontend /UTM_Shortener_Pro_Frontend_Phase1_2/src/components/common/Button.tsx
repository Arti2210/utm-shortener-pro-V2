import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost';
}

export default function Button({ variant='primary', className='', ...props }: ButtonProps) {
  const variants = {
    primary: 'bg-gold-400 text-primary-950 hover:scale-[1.02]',
    secondary: 'border border-gold-400/30',
    ghost: 'bg-transparent'
  };

  return (
    <button
      {...props}
      className={`px-4 py-2 rounded-lg transition-all ${variants[variant]} ${className}`}
    />
  );
}
