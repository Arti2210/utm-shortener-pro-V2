import React from 'react';

export default function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className="w-full rounded-lg border border-gold-400/20 px-4 py-3 bg-primary-950 outline-none focus:border-gold-400"
    />
  );
}
