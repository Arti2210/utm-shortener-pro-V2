import React from 'react';

export default function Card({ children }: { children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-gold-400/20 bg-primary-900 p-6 shadow-lg">
      {children}
    </div>
  );
}
