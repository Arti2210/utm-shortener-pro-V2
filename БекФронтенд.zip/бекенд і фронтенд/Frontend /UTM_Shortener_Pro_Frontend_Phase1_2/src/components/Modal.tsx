
export default function Modal({
  open,
  onClose,
  children,
}: any) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center" onClick={onClose}>
      <div className="bg-primary-900 rounded-xl p-6 w-full max-w-lg" onClick={(e)=>e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
}
