
import { useState } from 'react';
import { useAppStore } from '@/store/appStore';
import Modal from './Modal';

export default function Settings({ open, onClose }: any) {
  const { apiKey, setApiKey } = useAppStore();
  const [value, setValue] = useState(apiKey);

  return (
    <Modal open={open} onClose={onClose}>
      <h2 className="text-xl font-bold mb-4">Settings</h2>

      <input
        type="password"
        value={value}
        onChange={(e)=>setValue(e.target.value)}
        className="w-full border rounded-lg p-3"
      />

      <div className="flex gap-2 mt-4">
        <button
          onClick={() => {
            setApiKey(value);
            onClose();
          }}
          className="px-4 py-2 rounded-lg bg-gold-400 text-black"
        >
          Save
        </button>

        <button onClick={onClose}>
          Close
        </button>
      </div>
    </Modal>
  );
}
